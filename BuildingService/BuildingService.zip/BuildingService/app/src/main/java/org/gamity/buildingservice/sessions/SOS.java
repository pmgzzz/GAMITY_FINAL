package org.gamity.buildingservice.sessions;

public class SOS {
    public SOS () {

    }

    public void call () {

    }
}

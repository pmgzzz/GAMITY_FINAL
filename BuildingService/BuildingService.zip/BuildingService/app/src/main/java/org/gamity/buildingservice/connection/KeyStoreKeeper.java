package org.gamity.buildingservice.connection;

import android.content.Context;
import android.security.keystore.KeyProperties;
import androidx.security.crypto.MasterKey;

public class KeyStoreKeeper {
    Context context;
    MasterKey mainKey;

    public KeyStoreKeeper ( Context context ) {
        this.context = context;
        MasterKey mainKey = new MasterKey.Builder( context )
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build();
    }



}
